import { Data, animate, Override, Animatable } from 'framer'

const data = Data({ redHeartScale: Animatable(1), redHeartVisible: false })

export const RedHeart: Override = () => {
  return {
    scale: data.redHeartScale,
    visible: data.redHeartVisible,
  }
}
