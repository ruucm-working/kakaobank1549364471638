import { Data, animate, Override, Animatable } from 'framer'

const data = Data({
  redHeartScale: Animatable(1),
  redHeartVisible: false,
  blankHeartScale: Animatable(1),
  blankHeartVisible: true,

  whiteHeartScale: Animatable(1),
  whiteHeartVisible: false,
})

export const RedHeart: Override = () => {
  return {
    scale: data.redHeartScale,
    visible: data.redHeartVisible,
  }
}

export const BlankHeart: Override = () => {
  return {
    scale: data.blankHeartScale,
    visible: data.blankHeartVisible,
  }
}

export const WhiteHeart: Override = () => {
  return {
    scale: data.whiteHeartScale,
    visible: data.whiteHeartVisible,
  }
}

export const HeartButton: Override = () => {
  return {
    onTap() {
      data.blankHeartVisible = false
      data.redHeartVisible = true

      // animate
      data.redHeartScale.set(0.6)
      animate.spring(data.redHeartScale, 1)
    },
  }
}
